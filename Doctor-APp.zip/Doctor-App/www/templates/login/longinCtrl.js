docApp.controller('loginCtrl', ['$scope', function ($scope) {

    }]);
