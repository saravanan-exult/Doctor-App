docApp.controller('signupCtrl', ['$scope', function ($scope) {

    }]);
